#!/usr/bin/env python3
"""
Attacker Simulation Console for IDS + Recall-Aware Research Platform
Simulates adversarial network attacks, research black-box evasion algorithms,
and volumetric floods against the protected target server.

Research Attacks Supported:
  1. Silent Probing Attack (Offline perturbation without querying oracle)
  2. Surrogate Transferability Attack (Locally trained surrogate decision tree)
  3. Decision Boundary Attack (1D Bisection search vs benign reference pool)

Usage:
  python attacker_sim.py                     (Interactive Menu Console)
  python attacker_sim.py --mode silent       (Silent Probing Attack)
  python attacker_sim.py --mode surrogate    (Surrogate Transferability Attack)
  python attacker_sim.py --mode boundary     (Decision Boundary Bisection Attack)
  python attacker_sim.py --mode ddos         (DDoS Volumetric Burst)
  python attacker_sim.py --mode stream       (Continuous Real-time Traffic Stream)
  python attacker_sim.py --mode compare      (Base Defense vs Recall-Aware Benchmark)
"""

import sys
import os
import time
import json
import random
import argparse
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional, Dict, Any, List

import numpy as np
import pandas as pd

# Ensure UTF-8 output on Windows consoles if supported
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Add runtime_package to path for research attack imports
BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime_package"
if str(RUNTIME_DIR) not in sys.path:
    sys.path.insert(0, str(RUNTIME_DIR))

from attacks.silent_probing import SilentProbingAttack
from attacks.surrogate_transfer import SurrogateTransferAttack
from attacks.boundary_attack import DecisionBoundaryAttack

# ANSI Color Codes
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
WHITE = "\033[97m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_BLUE = "\033[44m"

DEFAULT_SERVER_URL = "http://localhost:8000/api/server/data"
DEFAULT_DEFENSE_URL = "http://localhost:8000/api/dashboard/set-defense"
DEFAULT_MODE_URL = "http://localhost:8000/api/dashboard/set-mode"
DEFAULT_TOGGLE_URL = "http://localhost:8000/api/dashboard/toggle-afp"

DEFAULT_SIM_START_URL = "http://localhost:8000/api/simulation/start"
DEFAULT_SIM_STOP_URL = "http://localhost:8000/api/simulation/stop"

def get_server_url() -> str:
    return DEFAULT_SERVER_URL

def get_base_url() -> str:
    if "/api/" in DEFAULT_SERVER_URL:
        return DEFAULT_SERVER_URL.split("/api/")[0]
    return DEFAULT_SERVER_URL.rstrip("/")

def get_defense_url() -> str:
    return f"{get_base_url()}/api/dashboard/set-defense"

def get_mode_url() -> str:
    return f"{get_base_url()}/api/dashboard/set-mode"

def get_sim_start_url() -> str:
    return f"{get_base_url()}/api/simulation/start"

def get_sim_stop_url() -> str:
    return f"{get_base_url()}/api/simulation/stop"

def get_reset_url() -> str:
    return f"{get_base_url()}/api/dashboard/reset"

def get_stats_url() -> str:
    return f"{get_base_url()}/api/dashboard/stats"

def set_target_url(target: str):
    global DEFAULT_SERVER_URL, DEFAULT_DEFENSE_URL, DEFAULT_MODE_URL, DEFAULT_TOGGLE_URL, DEFAULT_SIM_START_URL, DEFAULT_SIM_STOP_URL
    if "/api/" in target:
        base_url = target.split("/api/")[0]
        DEFAULT_SERVER_URL = target
    else:
        base_url = target.rstrip("/")
        DEFAULT_SERVER_URL = f"{base_url}/api/server/data"
    DEFAULT_DEFENSE_URL = f"{base_url}/api/dashboard/set-defense"
    DEFAULT_MODE_URL = f"{base_url}/api/dashboard/set-mode"
    DEFAULT_TOGGLE_URL = f"{base_url}/api/dashboard/toggle-afp"
    DEFAULT_SIM_START_URL = f"{base_url}/api/simulation/start"
    DEFAULT_SIM_STOP_URL = f"{base_url}/api/simulation/stop"

CURRENT_SIMULATION_SESSION_ID: Optional[str] = None

# Origin Pools for Simulation (Private IPs strictly labeled Private Network, public IPs Unknown)
ORIGIN_POOL = [
    {"ip": "203.0.113.45", "country": "Unknown"},
    {"ip": "185.199.110.23", "country": "Unknown"},
    {"ip": "103.21.54.12", "country": "Unknown"},
    {"ip": "45.76.32.18", "country": "Unknown"},
    {"ip": "89.248.163.77", "country": "Unknown"},
    {"ip": "114.119.130.88", "country": "Unknown"},
    {"ip": "177.54.144.20", "country": "Unknown"},
    {"ip": "197.232.12.9", "country": "Unknown"},
    {"ip": "10.0.2.45", "country": "Private Network"},
    {"ip": "172.16.0.12", "country": "Private Network"},
    {"ip": "10.0.3.77", "country": "Private Network"},
    {"ip": "192.168.1.25", "country": "Private Network"}
]

BENIGN_POOL = [
    {"ip": "172.16.0.5", "country": "Private Network"},
    {"ip": "192.168.1.100", "country": "Private Network"},
    {"ip": "10.0.1.22", "country": "Private Network"},
    {"ip": "192.168.1.45", "country": "Private Network"}
]


def print_banner():
    print(f"\n{CYAN}{BOLD}======================================================================{RESET}")
    print(f"{CYAN}{BOLD}  CYBER ATTACKER SIMULATION CONSOLE — RESEARCH RUNTIME{RESET}")
    print(f"{WHITE}  Target Protected Server: {BLUE}{get_server_url()}{RESET}")
    print(f"{WHITE}  Defense Layer:          {GREEN}Inline IDS + Defenses (AFP/RS/FS) + Recall-Aware Controller{RESET}")
    print(f"{CYAN}{BOLD}======================================================================{RESET}\n")


def send_packet(target_url: str, payload: dict) -> dict:
    """Sends HTTP POST to protected server and captures IDS verdict."""
    data_bytes = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        target_url,
        data=data_bytes,
        headers={"Content-Type": "application/json"}
    )
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            latency_ms = (time.perf_counter() - t0) * 1000
            res_body = json.loads(response.read().decode("utf-8"))
            return {
                "status_code": response.status,
                "latency_ms": latency_ms,
                "body": res_body,
                "blocked": (response.status == 403),
                "allowed": (response.status == 200),
                "error": None
            }
    except urllib.error.HTTPError as e:
        latency_ms = (time.perf_counter() - t0) * 1000
        try:
            body = json.loads(e.read().decode("utf-8"))
        except Exception:
            body = {"message": str(e)}
        return {
            "status_code": e.code,
            "latency_ms": latency_ms,
            "body": body,
            "blocked": (e.code == 403),
            "allowed": (e.code == 200),
            "error": None if e.code in (200, 403) else f"HTTP {e.code}"
        }
    except Exception as e:
        return {
            "status_code": 0,
            "latency_ms": 0,
            "body": {"error": str(e)},
            "blocked": False,
            "allowed": False,
            "error": str(e)
        }


def set_server_defense(defense_name: str) -> bool:
    """Configures server defense ('afp', 'rs', 'fs', 'none')."""
    payload = json.dumps({"defense": defense_name}).encode("utf-8")
    req = urllib.request.Request(get_defense_url(), data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return True
    except Exception as e:
        print(f"{RED}[Error] Failed to set defense: {e}{RESET}")
        return False


def set_server_mode(mode: str) -> bool:
    """Configures controller mode ('recall-aware', 'base')."""
    payload = json.dumps({"mode": mode}).encode("utf-8")
    req = urllib.request.Request(get_mode_url(), data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return True
    except Exception as e:
        print(f"{RED}[Error] Failed to set mode: {e}{RESET}")
        return False


def start_simulation_session(scenario_name: str, session_id: Optional[str] = None) -> str:
    """Notifies the protected server that an attack simulation session has begun."""
    global CURRENT_SIMULATION_SESSION_ID
    sess_id = session_id or f"sim-{int(time.time()*1000)%1000000:06d}"
    try:
        payload = json.dumps({"scenario": scenario_name, "session_id": sess_id}).encode("utf-8")
        req = urllib.request.Request(get_sim_start_url(), data=payload, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            CURRENT_SIMULATION_SESSION_ID = data.get("session_id", sess_id)
    except Exception:
        CURRENT_SIMULATION_SESSION_ID = sess_id
    return CURRENT_SIMULATION_SESSION_ID


def stop_simulation_session():
    """Notifies the protected server that the attack simulation session has ended."""
    global CURRENT_SIMULATION_SESSION_ID
    try:
        req = urllib.request.Request(get_sim_stop_url(), data=b"{}", headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            pass
    except Exception:
        pass
    CURRENT_SIMULATION_SESSION_ID = None


class RemoteServerOracle:
    """Oracle interface querying the target server via HTTP POST to /api/server/data."""
    def __init__(self, target_url: Optional[str] = None, max_queries_per_sample: int = 50, scenario_name: str = "Adversarial Query", session_id: Optional[str] = None):
        self.target_url = target_url or get_server_url()
        self.max_queries_per_sample = max_queries_per_sample
        self.scenario_name = scenario_name
        self.session_id = session_id
        self.queries = {}

    def predict(self, X, sample_ids=None, stage=None):
        if not isinstance(X, np.ndarray):
            X = np.array(X, dtype=np.float32)
        if X.ndim == 1:
            X = X.reshape(1, -1)

        preds = []
        sess_id = self.session_id or CURRENT_SIMULATION_SESSION_ID
        for i, row in enumerate(X):
            sid = sample_ids[i] if (sample_ids is not None and i < len(sample_ids)) else None

            origin = random.choice(ORIGIN_POOL)
            family = "Unknown"
            source_type = "Synthetic / Non-dataset"
            is_attack_val = None

            if sid is not None and ctx.meta_demo is not None and 0 <= sid < len(ctx.meta_demo):
                family = str(ctx.meta_demo.iloc[sid].get("attack_family", "Unknown"))
                true_y = int(ctx.meta_demo.iloc[sid]["y_binary"])
                is_attack_val = bool(true_y == 1)

                # Check if this row is the exact dataset row or a transformed candidate
                if ctx.X_demo is not None and 0 <= sid < len(ctx.X_demo):
                    orig_row = ctx.X_demo.iloc[sid].values.astype(np.float32)
                    if np.array_equal(row.astype(np.float32), orig_row):
                        source_type = "Dataset-derived"
                    else:
                        source_type = "Original sample family (Transformed)"
                        family = f"Transformed (Original: {family})"
                else:
                    source_type = "Dataset-derived"

            payload = {
                "source_ip": origin["ip"],
                "destination_ip": "192.168.1.10",
                "attack_scenario": self.scenario_name,
                "traffic_family": family,
                "traffic_family_source": source_type,
                "country": origin["country"],
                "is_attack": is_attack_val,
                "session_id": sess_id,
                "sample_id": int(sid) if sid is not None else None,
                "feature_vector": row.tolist()
            }
            res = send_packet(self.target_url, payload)
            query_key = sid if sid is not None else "unbound"
            # Accept only 403 as Attack (1) and 200 as Benign (0)
            if res["status_code"] == 403:
                self.queries[query_key] = self.queries.get(query_key, 0) + 1
                preds.append(1)
            elif res["status_code"] == 200:
                self.queries[query_key] = self.queries.get(query_key, 0) + 1
                preds.append(0)
            else:
                # 400/422/500 or transport error is an oracle error, not an evasion!
                err_body = res.get("body", {})
                err_msg = err_body.get("message") or err_body.get("error") or f"HTTP {res['status_code']}"
                raise RuntimeError(
                    f"Target oracle failure: HTTP {res['status_code']} from {self.target_url}: {err_msg}. "
                    f"This error cannot be interpreted as Benign or evasion."
                )

        return np.array(preds, dtype=int)

    def get_query_count(self, sample_id):
        return self.queries.get(sample_id, 0)


TargetOracle = RemoteServerOracle


class AttackerContext:
    """Loads required schemas and demo data for research attack execution."""
    def __init__(self):
        m_dir = RUNTIME_DIR / "model"
        d_dir = RUNTIME_DIR / "demo_data"

        with open(m_dir / "feature_names.json", "r") as f:
            self.feature_names = json.load(f)
        with open(m_dir / "feature_mask.json", "r") as f:
            mask_dict = json.load(f)
            self.modifiable_mask = np.array(list(mask_dict.values())[0], dtype=bool)

        self.bounds_df = pd.read_parquet(m_dir / "training_bounds.parquet")
        self.X_demo = pd.read_parquet(d_dir / "X_demo.parquet")
        self.meta_demo = pd.read_parquet(d_dir / "metadata_demo.parquet")

        self.attack_indices = np.where(self.meta_demo["y_binary"].values == 1)[0]
        self.benign_indices = np.where(self.meta_demo["y_binary"].values == 0)[0]


ctx = AttackerContext()


def run_single_flow(flow_type: Optional[str] = None, is_attack: bool = False, vector: Optional[np.ndarray] = None, sample_id: Optional[int] = None, scenario: str = "Background Traffic", session_id: Optional[str] = None):
    """Sends a single legitimate or volumetric packet to the server with real dataset metadata."""
    origin = random.choice(ORIGIN_POOL if is_attack else BENIGN_POOL)
    t_str = time.strftime("%H:%M:%S")

    feat_list = None
    chosen_idx = sample_id
    if vector is not None:
        feat_list = vector.tolist()
        resolved_family = flow_type or "Unknown"
        resolved_family_source = "Dataset-derived" if chosen_idx is not None else "Synthetic / Non-dataset"
    else:
        indices = ctx.attack_indices if is_attack else ctx.benign_indices
        if chosen_idx is None:
            chosen_idx = int(np.random.choice(indices))
        feat_list = ctx.X_demo.iloc[chosen_idx].values.tolist()
        resolved_family = str(ctx.meta_demo.iloc[chosen_idx].get("attack_family", "Normal" if not is_attack else "Unknown"))
        resolved_family_source = "Dataset-derived"

    active_sess = session_id if session_id is not None else CURRENT_SIMULATION_SESSION_ID

    payload = {
        "source_ip": origin["ip"],
        "destination_ip": "192.168.1.10",
        "attack_scenario": scenario,
        "traffic_family": resolved_family,
        "traffic_family_source": resolved_family_source,
        "country": origin["country"],
        "is_attack": is_attack,
        "session_id": active_sess,
        "sample_id": chosen_idx,
        "feature_vector": feat_list
    }

    res = send_packet(get_server_url(), payload)

    if res["status_code"] == 0:
        print(f"{RED}[FAIL] Could not connect to target server at {get_server_url()}. Is server.py running?{RESET}")
        return res

    if res["status_code"] not in [200, 403]:
        print(f"[{t_str}] {BG_RED}{WHITE}{BOLD} ERROR (HTTP {res['status_code']}) {RESET} Server returned error: {res['body']}")
        return res

    if res["blocked"]:
        badge = f"{BG_RED}{WHITE}{BOLD} BLOCKED (403) {RESET}"
        conf = res["body"].get("details", {}).get("confidence", "0.95")
        defense = res["body"].get("details", {}).get("defense", "active").upper()
        mode = res["body"].get("details", {}).get("mode", "").upper()
        used_int = res["body"].get("details", {}).get("used_intensity", "")
        print(f"[{t_str}] {badge} {resolved_family:<22} from {origin['ip']:<15} | Conf: {conf} | Defense: {defense} [{mode}] (used: {used_int})")
    else:
        badge = f"{BG_GREEN}{WHITE}{BOLD} ALLOWED (200) {RESET}"
        print(f"[{t_str}] {badge} {resolved_family:<22} from {origin['ip']:<15} | Server Status: Resource Granted (Benign)")

    return res


def run_volumetric_burst(attack_type: str = "DDoS", count: int = 6, delay: float = 0.25):
    """Sends a rapid burst of malicious packets to test throughput and alerts."""
    print(f"\n{RED}{BOLD}>>> Launching Volumetric Burst: {attack_type} ({count} packets)...{RESET}\n")
    for i in range(count):
        run_single_flow(flow_type=attack_type, is_attack=True)
        time.sleep(delay)
    print(f"\n{GREEN}[OK] Volumetric burst completed.{RESET}\n")


def run_silent_probing_attack():
    """
    Executes Research Attack 1: Silent Probing
    Sequential submission of unchanged baseline flows without querying target oracle (0 queries, no iterative perturbation).
    """
    print(f"\n{MAGENTA}{BOLD}======================================================================{RESET}")
    print(f"{MAGENTA}{BOLD}  RESEARCH ATTACK: SILENT PROBING ATTACK{RESET}")
    print(f"{WHITE}  Model: Sequential Submission of Unchanged Evaluation Flows (0 Queries){RESET}")
    print(f"{MAGENTA}{BOLD}======================================================================{RESET}\n")

    sess_id = start_simulation_session("Silent Probing")
    try:
        attack = SilentProbingAttack(ctx.feature_names, ctx.modifiable_mask, ctx.bounds_df)
        oracle = RemoteServerOracle(target_url=get_server_url(), scenario_name="Silent Probing", session_id=sess_id)

        # Pick an attack sample
        chosen_idx = int(np.random.choice(ctx.attack_indices))
        x_orig = ctx.X_demo.iloc[chosen_idx].values
        family = str(ctx.meta_demo.iloc[chosen_idx].get("attack_family", "Unknown"))

        print(f"{WHITE}Selected Base Attack Vector: {CYAN}{family}{RESET} (Sample ID: {chosen_idx})")
        print(f"{DIM}Submitting unchanged baseline flow (Silent Probing makes 0 target queries)...{RESET}")

        res = attack.generate(x_orig, oracle, sample_id=chosen_idx, true_label=1)
        print(f"{GREEN}[OK] Flow prepared (no modification). Transmitting to protected server endpoint...{RESET}")

        origin = random.choice(ORIGIN_POOL)
        payload = {
            "source_ip": origin["ip"],
            "destination_ip": "192.168.1.10",
            "attack_scenario": "Silent Probing",
            "traffic_family": family,
            "traffic_family_source": "Dataset-derived",
            "country": origin["country"],
            "is_attack": True,
            "session_id": sess_id,
            "sample_id": chosen_idx,
            "feature_vector": res.X_adv.tolist()
        }

        resp = send_packet(get_server_url(), payload)
        t_str = time.strftime("%H:%M:%S")

        if resp["status_code"] not in [200, 403]:
            print(f"[{t_str}] {BG_RED}{WHITE}{BOLD} ERROR (HTTP {resp['status_code']}) {RESET} {resp['body']}\n")
            return

        if resp["blocked"]:
            details = resp["body"].get("details", {})
            print(f"[{t_str}] {BG_RED}{WHITE}{BOLD} DETECTED & BLOCKED (403) {RESET}")
            print(f"IDS Classification: ATTACK | Family: {family} | Defense: {details.get('defense', '').upper()} [{details.get('mode', '').upper()}]")
            print(f"{CYAN}Analysis: Target IDS classified silent probing flow as Attack.{RESET}\n")
        else:
            print(f"[{t_str}] {BG_GREEN}{WHITE}{BOLD} EVADED & ALLOWED (200) {RESET}")
            print(f"IDS Classification: BENIGN | Family: {family}")
            print(f"{YELLOW}Warning: Attack penetrated protected server under current defense configuration.{RESET}\n")
    finally:
        stop_simulation_session()


def run_surrogate_transfer_attack():
    """
    Executes Research Attack 2: Surrogate Transferability
    Trains a local Decision Tree surrogate from oracle queries and crafts transfer attacks.
    """
    print(f"\n{MAGENTA}{BOLD}======================================================================{RESET}")
    print(f"{MAGENTA}{BOLD}  RESEARCH ATTACK: SURROGATE TRANSFERABILITY ATTACK{RESET}")
    print(f"{WHITE}  Model: Local Decision Tree Surrogate with Boundary Transfer{RESET}")
    print(f"{MAGENTA}{BOLD}======================================================================{RESET}\n")

    sess_id = start_simulation_session("Surrogate Transferability")
    try:
        attack = SurrogateTransferAttack(ctx.feature_names, ctx.modifiable_mask, ctx.bounds_df)
        oracle = RemoteServerOracle(target_url=get_server_url(), scenario_name="Surrogate Transferability", session_id=sess_id)

        print(f"{DIM}Fitting surrogate model on local sample distribution...{RESET}")
        x_pool = ctx.X_demo.values
        y_oracle = oracle.predict(x_pool, sample_ids=list(range(len(x_pool))), stage="surrogate_fitting")
        attack.fit_surrogate(x_pool, y_oracle)
        print(f"{GREEN}[OK] Surrogate decision tree fitted with benign class resolved.{RESET}")

        chosen_idx = int(np.random.choice(ctx.attack_indices))
        x_orig = ctx.X_demo.iloc[chosen_idx].values
        family = str(ctx.meta_demo.iloc[chosen_idx].get("attack_family", "Unknown"))

        print(f"{WHITE}Targeting Attack Sample: {CYAN}{family}{RESET}")
        x_cand, _ = attack.generate_candidate(x_orig)

        print(f"{DIM}Evaluating transfer vector against protected target server...{RESET}")
        transfer_res = attack.evaluate_transfer(x_cand, x_orig, oracle, sample_id=chosen_idx, true_label=1)

        t_str = time.strftime("%H:%M:%S")
        if transfer_res.success:
            print(f"[{t_str}] {BG_GREEN}{WHITE}{BOLD} TRANSFER SUCCESS (200 OK) {RESET}")
            print(f"IDS Classification: BENIGN (EVASION SUCCESS) | Family: {family}")
            print(f"{YELLOW}Result: Adversarial candidate transferred and evaded target classifier!{RESET}\n")
        else:
            print(f"[{t_str}] {BG_RED}{WHITE}{BOLD} TRANSFER BLOCKED (403 FORBIDDEN) {RESET}")
            print(f"IDS Classification: ATTACK (DEFENSE HELD) | Family: {family}")
            print(f"{CYAN}Result: Target IDS defense prevented surrogate boundary transfer.{RESET}\n")
    finally:
        stop_simulation_session()


def run_decision_boundary_attack(max_queries: int = 50, steps: int = 10):
    """
    Executes Research Attack 3: Decision Boundary Bisection Search
    Uses benign references and binary search to identify adversarial boundary vectors.
    """
    print(f"\n{MAGENTA}{BOLD}======================================================================{RESET}")
    print(f"{MAGENTA}{BOLD}  RESEARCH ATTACK: DECISION BOUNDARY ATTACK (1D BISECTION){RESET}")
    print(f"{WHITE}  Model: Query-Guided Binary Search Boundary Finding{RESET}")
    print(f"{MAGENTA}{BOLD}======================================================================{RESET}\n")

    sess_id = start_simulation_session("Decision-Boundary Attack")
    try:
        attack = DecisionBoundaryAttack(
            ctx.feature_names, ctx.modifiable_mask, ctx.bounds_df,
            max_queries=max_queries, binary_search_steps=steps
        )
        oracle = RemoteServerOracle(target_url=get_server_url(), max_queries_per_sample=max_queries, scenario_name="Decision-Boundary Attack", session_id=sess_id)
        reference_pool = ctx.X_demo.iloc[ctx.benign_indices].values

        chosen_idx = int(np.random.choice(ctx.attack_indices))
        x_orig = ctx.X_demo.iloc[chosen_idx].values
        family = str(ctx.meta_demo.iloc[chosen_idx].get("attack_family", "Unknown"))

        print(f"{WHITE}Target Attack Sample: {CYAN}{family}{RESET} (ID: {chosen_idx})")
        print(f"{DIM}Running bisection search via live server queries (max budget: {max_queries})...{RESET}")

        res = attack.generate(x_orig, oracle, sample_id=chosen_idx, true_label=1, reference_pool=reference_pool)

        t_str = time.strftime("%H:%M:%S")
        queries_used = oracle.get_query_count(chosen_idx)
        print(f"\n[{t_str}] {BOLD}Boundary Search Outcome:{RESET}")
        print(f"  Status Code:   {CYAN}{res.status_code}{RESET}")
        print(f"  Total Queries: {YELLOW}{queries_used}{RESET} / {max_queries}")
        print(f"  Message:       {res.message}")

        if res.success:
            print(f"  Verdict:       {BG_GREEN}{WHITE}{BOLD} EVADED BOUNDARY (BENIGN PREDICTED) {RESET}\n")
        else:
            print(f"  Verdict:       {BG_RED}{WHITE}{BOLD} DEFENSE HELD / ATTACK DETECTED {RESET}\n")
    finally:
        stop_simulation_session()


def run_comparative_benchmark():
    """
    Local Control-Path Demonstration:
    Demonstrates defense control-path behavior by sending the exact same sequence of 5 flows
    first under Base Defense (fixed intensity) and then under Recall-Aware Defense (adaptive controller).
    Note: Local control-path illustration on identical sample sequence, distinct from the Phase 10/11
    statistical benchmark (which evaluated 144 measurement batches of 500 records).
    """
    print(f"\n{YELLOW}{BOLD}======================================================================{RESET}")
    print(f"{YELLOW}{BOLD}  LOCAL CONTROL-PATH DEMONSTRATION: BASE vs. RECALL-AWARE{RESET}")
    print(f"{WHITE}  Evaluating identical 5-flow sequence under fixed vs adaptive controller{RESET}")
    print(f"{YELLOW}{BOLD}======================================================================{RESET}\n")

    # Pick 5 fixed attack samples for exact repeatability
    fixed_indices = ctx.attack_indices[:5].tolist()

    # Step 1: Base Mode
    print(f"{WHITE}Step 1: Setting AFP Defense to {YELLOW}BASE MODE (Static Calibrated Intensity){RESET}...")
    if not set_server_defense("afp") or not set_server_mode("base"):
        print(f"{RED}[FAIL] Setup failed for Base mode.{RESET}")
        return

    # Reset dashboard metrics to clean baseline
    try:
        req = urllib.request.Request(get_reset_url(), data=b"{}", headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3)
    except Exception as e:
        print(f"{RED}[FAIL] Reset failed: {e}{RESET}")
        return
    time.sleep(0.5)

    print(f"{DIM}Sending 5 fixed attack flows under Base AFP...{RESET}")
    for idx in fixed_indices:
        x_row = ctx.X_demo.iloc[idx].values
        fam = str(ctx.meta_demo.iloc[idx].get("attack_family", "Unknown"))
        r = run_single_flow(flow_type=fam, is_attack=True, vector=x_row, sample_id=idx, scenario="Base Demonstration")
        if r is None or r.get("status_code") not in (200, 403):
            print(f"{RED}[FAIL] Error during Base mode flow transmission.{RESET}")
            return
        time.sleep(0.2)

    time.sleep(0.8)

    # Step 2: Recall-Aware Mode
    print(f"\n{WHITE}Step 2: Activating {GREEN}RECALL-AWARE CONTROLLER (Dynamic Feedback Window){RESET}...")
    if not set_server_mode("recall-aware"):
        print(f"{RED}[FAIL] Setup failed for Recall-Aware mode.{RESET}")
        return

    # Reset dashboard metrics to clean baseline
    try:
        req = urllib.request.Request(get_reset_url(), data=b"{}", headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3)
    except Exception as e:
        print(f"{RED}[FAIL] Reset failed: {e}{RESET}")
        return
    time.sleep(0.5)

    sess_id = start_simulation_session("Recall-Aware Demonstration")
    results_recall = []
    try:
        print(f"{DIM}Sending the SAME 5 attack flows under Recall-Aware AFP...{RESET}")
        for idx in fixed_indices:
            x_row = ctx.X_demo.iloc[idx].values
            fam = str(ctx.meta_demo.iloc[idx].get("attack_family", "Unknown"))
            r = run_single_flow(flow_type=fam, is_attack=True, vector=x_row, sample_id=idx, scenario="Recall-Aware Demonstration", session_id=sess_id)
            if r is None or r.get("status_code") not in (200, 403):
                print(f"{RED}[FAIL] Error during Recall-Aware mode flow transmission.{RESET}")
                return
            results_recall.append(r)
            time.sleep(0.2)
    finally:
        stop_simulation_session()

    # Query final telemetry from server to verify actual observed state
    dashboard_data = None
    try:
        req = urllib.request.Request(get_stats_url())
        with urllib.request.urlopen(req, timeout=3) as resp:
            dashboard_data = json.loads(resp.read().decode())
    except Exception as e:
        print(f"{YELLOW}[!] Could not fetch final dashboard telemetry: {e}{RESET}")

    stats = dashboard_data.get("stats", {}) if isinstance(dashboard_data, dict) else {}
    afp_info = dashboard_data.get("afp", {}) if isinstance(dashboard_data, dict) else {}

    raw_intensity = afp_info.get("intensity") if isinstance(afp_info, dict) else None
    obs_state = afp_info.get("controller_state") if isinstance(afp_info, dict) else None

    obs_intensity_str = f"{raw_intensity:.5f}" if isinstance(raw_intensity, (int, float)) else None
    has_controller_telemetry = (obs_intensity_str is not None and obs_state is not None)

    detected_count = sum(1 for r in results_recall if r.get("blocked"))
    total_count = len(results_recall)

    tp_count = stats.get("tp", detected_count)
    fn_count = stats.get("fn", total_count - detected_count)

    print(f"\n{CYAN}{BOLD}Demonstration completed. Check the SOC dashboard!{RESET}")
    print(f"{WHITE}Observed Run Results: {detected_count}/{total_count} attack flows detected (TP={tp_count}, FN={fn_count}).{RESET}")

    if not has_controller_telemetry:
        print(f"{YELLOW}Controller telemetry is unavailable; cannot confirm final intensity or state.{RESET}\n")
    elif detected_count == total_count:
        print(f"{WHITE}With all {total_count} attack flows detected (Recall = 1.000 >= Rmin), the controller maintained intensity={obs_intensity_str} in {obs_state} state.{RESET}")
        print(f"{DIM}Note: If lower recall occurs (e.g., under adversarial evasion), the controller adapts downward (0.00030 -> 0.00012). See the automated test suite for the verified adaptation sequence.{RESET}\n")
    else:
        print(f"{WHITE}Observed evasion resulted in controller adaptation: intensity={obs_intensity_str}, state={obs_state}.{RESET}\n")


def run_continuous_stream(delay: float = 1.0):
    """Streams live network traffic to demonstrate real-time dashboard updates."""
    print(f"\n{CYAN}{BOLD}>>> Starting Continuous Traffic & Threat Stream (Press Ctrl+C to stop)...{RESET}\n")
    attack_types = ["DDoS", "Port Scan", "Brute Force", "Malware", "Bot", "SlowHTTPTest"]

    try:
        while True:
            is_attack = (random.random() < 0.35)
            if is_attack:
                a_type = random.choice(attack_types)
                run_single_flow(flow_type=a_type, is_attack=True)
            else:
                run_single_flow(flow_type="Normal", is_attack=False)
            time.sleep(delay)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] Stream paused by user.{RESET}\n")


def interactive_menu():
    print_banner()
    while True:
        print(f"{WHITE}{BOLD}======================================================================{RESET}")
        print(f"{CYAN}{BOLD}  ATTACKER ACTIONS (Black-Box Simulation POV):{RESET}")
        print(f"  {CYAN}[1]{RESET} Send Legitimate Benign Traffic Flow")
        print(f"  {RED}[2]{RESET} Launch DDoS Volumetric Flood Burst")
        print(f"  {MAGENTA}[3]{RESET} Launch Silent Probing (Sequential Unchanged Baseline Flows, 0 Queries)")
        print(f"  {MAGENTA}[4]{RESET} Launch Surrogate Transferability Attack (Decision Tree Surrogate)")
        print(f"  {MAGENTA}[5]{RESET} Launch Decision Boundary Attack (1D Bisection Search)")
        print(f"  {BLUE}[6]{RESET} Continuous Real-time Traffic Stream (1 flow / sec)")
        print(f"")
        print(f"{YELLOW}{BOLD}  OPERATOR SETUP CONTROLS (Local Experiment Configuration):{RESET}")
        print(f"  {YELLOW}[7]{RESET} Local Control-Path Demonstration: Base vs. Recall-Aware (Identical Flows)")
        print(f"  {WHITE}[8]{RESET} Switch Active Defense: [AFP -> RS -> FS -> None]")
        print(f"  {WHITE}[9]{RESET} Toggle Controller Mode: [Recall-Aware <-> Base]")
        print(f"  {DIM}[0]{RESET} Exit")
        print(f"{WHITE}{BOLD}======================================================================{RESET}\n")

        try:
            choice = input(f"{BOLD}Enter option (0-9): {RESET}").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting.")
            sys.exit(0)

        if choice == "1":
            run_single_flow(flow_type="Normal", is_attack=False)
        elif choice == "2":
            run_volumetric_burst("DDoS", count=6, delay=0.25)
        elif choice == "3":
            run_silent_probing_attack()
        elif choice == "4":
            run_surrogate_transfer_attack()
        elif choice == "5":
            run_decision_boundary_attack()
        elif choice == "6":
            run_continuous_stream(delay=1.0)
        elif choice == "7":
            run_comparative_benchmark()
        elif choice == "8":
            cycle = {"afp": "rs", "rs": "fs", "fs": "none", "none": "afp"}
            try:
                with urllib.request.urlopen(get_stats_url(), timeout=3) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    curr = data.get("afp", {}).get("defense_name", "afp")
                    nxt = cycle.get(curr, "afp")
                    set_server_defense(nxt)
                    print(f"Defense switched to: {GREEN}{nxt.upper()}{RESET}\n")
            except Exception as e:
                print(f"{RED}Could not cycle defense: {e}{RESET}\n")
        elif choice == "9":
            try:
                with urllib.request.urlopen(get_stats_url(), timeout=3) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    curr_mode = data.get("afp", {}).get("mode", "recall-aware")
                    nxt_mode = "base" if curr_mode == "recall-aware" else "recall-aware"
                    set_server_mode(nxt_mode)
                    print(f"Controller Mode switched to: {CYAN}{nxt_mode.upper()}{RESET}\n")
            except Exception as e:
                print(f"{RED}Could not toggle mode: {e}{RESET}\n")
        elif choice == "0":
            print("Exiting attacker simulation console.")
            break
        else:
            print(f"{RED}Invalid selection. Please choose 0-9.{RESET}\n")


def main():
    parser = argparse.ArgumentParser(description="Attacker Simulation Console for IDS + Recall-Aware Platform")
    parser.add_argument("--mode", choices=["menu", "silent", "surrogate", "boundary", "ddos", "benign", "stream", "compare"], default="menu")
    parser.add_argument("--defense", choices=["afp", "rs", "fs", "none"], default=None)
    parser.add_argument("--controller", choices=["recall-aware", "base"], default=None)
    parser.add_argument("--target", default=DEFAULT_SERVER_URL, help="Target URL for protected server endpoint")
    parser.add_argument("--count", type=int, default=5)
    parser.add_argument("--delay", type=float, default=0.3)

    args = parser.parse_args()

    # Make --target effective for all server endpoints dynamically
    if args.target:
        set_target_url(args.target)

    if args.defense:
        set_server_defense(args.defense)
    if args.controller:
        set_server_mode(args.controller)

    if args.mode == "menu":
        interactive_menu()
    elif args.mode == "silent":
        run_silent_probing_attack()
    elif args.mode == "surrogate":
        run_surrogate_transfer_attack()
    elif args.mode == "boundary":
        run_decision_boundary_attack(max_queries=50)
    elif args.mode == "compare":
        run_comparative_benchmark()
    elif args.mode == "ddos":
        run_volumetric_burst("DDoS", count=args.count, delay=args.delay)
    elif args.mode == "benign":
        run_single_flow("Normal", is_attack=False)
    elif args.mode == "stream":
        run_continuous_stream(delay=args.delay)


if __name__ == "__main__":
    main()
