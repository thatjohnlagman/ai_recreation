# THESIS TOOL DEFENSE READINESS REPORT
**Standalone ML-IDS Demonstration Platform (`ai_recreation`)**  
**Audit & Defense Preparation Date:** October 6, 2026  
**Auditor / Implementation Agent:** Antigravity (Google DeepMind)

---

## 1. Executive Summary & Git Repository State

This report certifies the defense readiness and audit corrections of the standalone IDS demonstration repository (`ai_recreation`). All requirements from the audit—including strict float32 input validation, exact dataset label precedence, per-sample oracle feedback resolution, truthful controller adaptation proofs via genuine adversarial candidates, conditional benchmark reporting, offline asset resilience, untrusted dashboard text sanitization, and packaging integrity—have been implemented, tested, and verified on the defense target environment.

### Git State Metadata
- **Repository Root**: `c:\Users\reddr\ai_recreation`
- **Active Git Branch**: `integrate-runtime-demo`
- **Starting Git Commit**: `a240ecc3d7934a229ee0fdb72a97d04615de06a0`
- **Working Tree State**: Tracked with targeted fixes in `server.py`, `attacker_sim.py`, `README.md`, `RUNNING_INSTRUCTIONS.md`, `tests/verify_defense_readiness.py`, and `create_package.py`.
- **Packaging Standard**: Per security best practices, the packaged archive includes `FILE_MANIFEST.csv` certifying the cryptographic SHA-256 hash of every included file. The archive's own outer SHA-256 checksum is published and verified externally outside the archive to prevent circular hash dependencies.

---

## 2. Source-of-Truth Invariants Verified

| Invariant | Specification / Expectation | Verified State |
| :--- | :--- | :--- |
| **Model Checksum** | SHA-256 `9608672c5d5e38a9272c560679cdd2291399de0e0917c8c9dff373bfd200f51d` | **EXACT MATCH** (Verified via hashlib SHA-256) |
| **Model Architecture** | 200-tree binary RandomForest (`[0, 1]`), 78 numeric features | **EXACT MATCH** (`n_estimators=200`, `n_features_in_=78`, `classes_=[0, 1]`) |
| **Feature Mask** | Exactly 63 modifiable and 15 protected features | **EXACT MATCH** (`sum(mask)==63`, `sum(~mask)==15`) |
| **Defense Naming** | Adaptive Feature Poisoning (AFP) (Perturbation in thesis title) | **CONFIRMED & DOCUMENTED** |
| **AFP Formulation** | Bounded noise scaled by standard deviation; **no** centroid projection | **PRESERVED** (deviation-scaled noise, clipped to training bounds) |
| **AFP Calibrated Parameters** | Final Phase 8 calibration: $\varepsilon = 0.0003$, $\alpha = 0.5$ | **CONFIGURED & PRESERVED** |
| **Controller C1 Config** | Slow decay $\beta_{slow} = 0.90$, Fast decay $\beta_{fast} = 0.40$ | **CONFIRMED & PRESERVED** (Corrected in README documentation) |
| **RS Ensemble Size** | 11 members configured in `defenses.yaml` | **PRESERVED & VERIFIED** (11 noise members, vote fraction reported) |
| **Silent Probing Semantics** | Sequential submission of unchanged baseline flows (0 target queries) | **VERIFIED** (Follows `runtime_package/attacks/silent_probing.py`) |
| **Legacy Files Isolation** | Historical 77-feature files (`models/`, `datasets/demo/`) and historical prototype (`archive/`) excluded from distribution | **EXCLUDED & DOCUMENTED** (Keeps distribution focused on active runtime demonstration) |

---

## 3. Work Order Resolution (Issues Fixed)

### P0. Truthful Observations, Provenance & Adaptation

1. **Exact Dataset Label Precedence (`server.py:559–567`)**:
   - *Issue*: Simulator feedback was previously checked before exact dataset matching (`is_exact_sample`). Thus, if a client or script submitted an exact benign dataset vector with an active session and `is_attack=True`, it was recorded as `Simulator: 1`, creating an artificial false negative and decaying the controller.
   - *Fix*: Authoritative labels from `metadata_demo.parquet` now strictly take precedence for all exact dataset samples (`Dataset: 0` or `Dataset: 1`), regardless of caller-supplied `is_attack`. Any conflicting feedback is explicitly ignored with provenance logging (`[Provenance] Ignored conflicting simulator feedback...`). Simulator feedback (`Simulator: <y>`) is restricted to properly bound transformed/unbound vectors in an authorized simulation session.
   - *Regression Verification*: Tested in Check 6 (Test 11): submitting an exact benign row with `is_attack=True` remains `Dataset: 0` (TN=1, FN=0), and an exact attack row with `is_attack=False` remains `Dataset: 1` (TP=1, FP=0).

2. **Per-Sample Oracle Feedback Resolution (`attacker_sim.py:270–305`)**:
   - *Issue*: `RemoteServerOracle.predict` previously hardcoded `is_attack=True` for every query. When `run_surrogate_transfer_attack()` fitted its local surrogate on the 20-row demo pool, benign references (samples 0–9) were sent with `is_attack=True`, artificially creating false negatives under earlier label logic.
   - *Fix*: `RemoteServerOracle.predict` now resolves ground truth dynamically per sample. For known demo samples (`sample_id` present), `is_attack` is derived from `ctx.meta_demo.iloc[sid]["y_binary"] == 1`. For adversarial transformations derived from an attack sample, `is_attack=True` is retained. For unbound or unknown vectors, `is_attack=None` is transmitted.
   - *Verification*: Tested in Check 10 Part 3: submitting the 20 demo reference samples through the surrogate fitting HTTP path cleanly registers 10 True Negatives (0 FN, 0 FP) for benign rows and advances the controller batch counter to `batch_id=2` across the 10 attack rows.

3. **Truthful Controller Adaptation via Genuine Evasion Candidate (`tests/verify_defense_readiness.py:284–360`)**:
   - *Issue*: Check 7 previously took benign dataset vectors and relabeled them with `is_attack=True` to manufacture 5 synthetic false negatives. This was a synthetic fault-injection test, not evidence of actual attack evasion.
   - *Fix*: Replaced synthetic relabeling with a truthful functional rehearsal:
     - In static Base AFP mode ($\varepsilon = 0.00030$), `DecisionBoundaryAttack.generate` crafts a genuine adversarial evasion candidate from attack sample 10 (DoS attacks-SlowHTTPTest).
     - Verified: original sample label is Attack (`y_binary == 1`), all 15 protected features are preserved exactly, vector is finite and bounded within training limits, and candidate receives a Benign verdict (`200 OK`, `FORWARDED`) under Base AFP (solved in 13 queries).
     - Reset server to Recall-Aware AFP, then replay 5 correctly labeled copies in an authorized simulation session (`Simulator: 1`).
     - Verified actual verdicts: flows 1–4 record False Negatives; on flow 5, `used_intensity` is truthfully reported as `0.00030`, `next_intensity` adapts down to `0.00012` ($\beta_{fast} \times 0.00030$, state transitions to Red); flow 6 immediately uses `0.00012` during inference.

4. **Conditional Comparison Summaries & Telemetry Decoding (`attacker_sim.py:640–665`)**:
   - *Issue*: `run_comparative_benchmark()` previously looked for `current_intensity` and `controller_state` inside `response['stats']`, where they do not exist (the server places confusion counts in `stats` and controller intensity/state in `afp`). This produced `'intensity=N/A, state=N/A'` or unverified claims.
   - *Fix*: Retained the full decoded dashboard response from `/api/dashboard/stats`. Confusion counts are read from the `stats` section (`tp`, `fn`) and actual controller intensity and state are read from the `afp` section (`afp['intensity']`, `afp['controller_state']`). Formatted intensity to five decimal places (`{intensity:.5f}`). Both outcome branches truthfully report returned controller fields without hardcoded substitutes. If stats retrieval fails or fields are missing, the summary explicitly reports that controller telemetry is unavailable rather than fabricating state or transition claims.
   - *Validation*: Tested against all 3 regression scenarios: (1) 5/5 detected with Green/0.00030 correctly reports 5/5 and observed Green/0.00030; (2) 4/5 detected with Red/0.00012 reports 4/5 and observed Red/0.00012 with zero 'N/A' tokens; (3) failed telemetry retrieval explicitly states controller telemetry is unavailable.

5. **Strict Origin Equality & Claimed Family Disambiguation (`server.py:515-532`)**:
   - Origin verification enforces exact binary equality on the converted float32 array: `np.array_equal(features, orig_row.astype(np.float32))`. When a vector does not match the referenced dataset row, it is explicitly attributed as `Claimed original family: <Family>` unless bound to a validated simulation session. Tests verify that attaching attack sample 10's vector to sample ID 0 results in an `Attack` classification, `Claimed original family: Benign`, status `Unlabeled`, and zero metric contamination.

6. **Finite Check Post-Float32 Conversion (`server.py:488-498`)**:
   - Converted the 78-element vector to `np.float32` first, then immediately validated `np.isfinite(features).all()`. Submitting `1e40` deterministically returns HTTP 400 Bad Request.

### P1. Usability, Interface Security & Offline Integrity

7. **Documentation Consistency (`README.md`, `RUNNING_INSTRUCTIONS.md`)**:
   - Corrected C1 slow decay parameter in root `README.md` from `0.85` to `0.90` (matching preserved `controller.yaml` configuration).
   - Documented that the readiness suite contains 12 checks (not 10).
   - Updated `RUNNING_INSTRUCTIONS.md` to install dependencies from root `requirements.txt`, preserving the tested `scikit-learn==1.6.1` pin.
   - Documented Adaptive Feature Poisoning (AFP) as the defense name, noting thesis title Perturbation wording.
   - Documented that `archive/` contains historical prototype code and is excluded from the distribution archive.

8. **Dynamic Target Resolution (`attacker_sim.py:100–120`)**:
   - `set_target_url` intelligently resolves base hosts (`http://127.0.0.1:8000`) and endpoint paths (`http://127.0.0.1:8000/api/server/data`), dynamically updating server, defense, mode, reset, and simulation endpoints.

9. **Untrusted Dashboard Text Sanitization (`frontend/app.js:15-28, 590-710`)**:
   - Added `escapeHtml()` sanitization helper. Escaped all request-derived fields before rendering into `innerHTML`. Verified in Check 11 against `<script>alert('xss')</script>`.

10. **Offline Assets & Vendoring (`frontend/vendor/`)**:
    - Vendored `leaflet.js`, `leaflet.css`, and `chart.umd.min.js`. Dashboard operates completely offline.

---

## 4. Automated Verification & Test Evidence

All verification suites were executed directly on the defense target system (`Windows`, `Python 3.13.14`, `scikit-learn 1.6.1`).

### Test Suite Summary

| Test Suite / Script | Command Executed | Tests Run | Result | Evidence / Details |
| :--- | :--- | :---: | :---: | :--- |
| **Comprehensive Readiness Suite** | `python -u tests/verify_defense_readiness.py` | 12 / 12 | **100% PASS** | Checks 1–12 all passed (model SHA-256, mask, CLI, oracle errors, cold start, label precedence regression test, genuine evasion candidate replay adaptation proof, seed independence, provenance, surrogate fitting HTTP path accounting, HTML escaping, dynamic target). |
| **Audit Test Runner (A–G)** | `python -u tests/run_audit_tests.py` | 7 / 7 | **100% PASS** | Tests A–G all passed (no attacker, silent probing, genuine boundary attack evasion, dataset family, unknown synthetic, IP geolocation, mode toggle). |
| **Pytest Live System & Master Directive** | `pytest tests/test_live_system.py tests/test_master_directive.py -v` | 10 / 10 | **100% PASS** | All 10 live system and master directive tests passed cleanly in 45.05s. |

### Defense Readiness Verification Output

```text
=================================================================
  STARTING DEFENSE READINESS VERIFICATION SUITE
=================================================================

>> [Check 1] Verifying Model SHA-256 and Specifications...
   [PASS] Model SHA-256: 9608672c5d5e38a9272c560679cdd2291399de0e0917c8c9dff373bfd200f51d
   [PASS] 200 trees, 78 features, classes [np.int8(0), np.int8(1)]

>> [Check 2] Verifying Feature Mask and Training Bounds...
   [PASS] Feature mask: 63 modifiable, 15 protected (total 78)
   [PASS] Training bounds: 78 features verified.

>> [Check 3] Verifying Standalone Offline CLI (run.py)...
   [PASS] Offline CLI run.py executed across batch boundary successfully.

>> [Check 4] Verifying TargetOracle Error Handling...
   [PASS] TargetOracle correctly propagates errors and does NOT count failed queries.

>> [Check 5] Verifying Cold Start & Reset Truthfulness...
   [PASS] Total traffic: 0 | Detected attacks: 0 | Recall: None | FPR: None
   [PASS] Threat locations: [] | Recent feed: []

>> [Check 6] Verifying Input Validation, Origin Checking & Session Authorization...
   [PASS] 1e40 overflow rejected (400). Mismatched origin labeled claimed original family.
   [PASS] Exact dataset labels strictly take precedence over conflicting simulator feedback.
   [PASS] Arbitrary session strings rejected; validated sessions accept simulator feedback.

>> [Check 7] Verifying Used vs Next Intensity & Proving Controller Adaptation...
   [PASS] 5/5 Detections: Controller holds at calibrated ceiling (0.00030 -> 0.00030, Green).
   [PASS] Deterministic Adaptation Proved: Flow 5 used=0.00030, next=0.00012; Flow 6 used=0.00012.

>> [Check 8] Verifying Scenario Seed Independence...
   [PASS] Attack scenario string does not manipulate defense RNG or verdict.

>> [Check 9] Verifying Provenance and Geolocation Truthfulness...
   [PASS] Public IP location: Unknown | Private IP: Private Network
   [PASS] Synthetic flow provenance: Unknown (Synthetic / Non-dataset)

>> [Check 10] Verifying Attack Classes Smoke Execution...
   [PASS] SilentProbingAttack: 0 queries, exact unperturbed copy verified.
   [PASS] DecisionBoundaryAttack completed: status=SUCCESS, queries_used=13/50
   [PASS] Surrogate Fitting HTTP Path: 10 Benign references -> 10 TN, 0 FN; 10 Attack references -> batch_id progressed to 2.

>> [Check 11] Verifying HTML Escaping & Injection Protection...
   [PASS] Untrusted request-derived strings are neutralized by HTML escaping.

>> [Check 12] Verifying Dynamic Target Resolution in Attacker Sim...
   [PASS] Dynamic --target resolution verified for all endpoints and oracles.

=================================================================
  ALL 12 DEFENSE READINESS CHECKS PASSED SUCCESSFULLY!
=================================================================
```

---

## 5. Thesis Defense Rehearsal Script

Follow this validated rehearsal walkthrough during the committee examination.

### Step 1: Environment & Server Launch (Terminal 1)
```powershell
cd c:\Users\reddr\ai_recreation
.\.venv\Scripts\python.exe server.py
```
- Open browser to `http://localhost:8000`.
- **Points to Highlight to Committee**:
  1. **Honest Cold Start**: Observe that Total Traffic is 0, Detected Attacks is 0, Recall and FPR display `—` (unavailable zero denominator), Recent Feed is empty, and Threat Locations displays an empty map. No mock figures or pre-seeded data are present.
  2. **Offline Resilience**: Styling, system fonts, Chart.js, and Leaflet scripts load locally from `frontend/vendor/` with zero external font/script CDN calls. Explain truthfully that while live basemap tiles load when internet is present, the dashboard runs 100% locally with a neutral fallback canvas when offline.

### Step 2: Benign Baseline Flow (Terminal 2)
```powershell
cd c:\Users\reddr\ai_recreation
.\.venv\Scripts\python.exe -c "import requests; r = requests.post('http://localhost:8000/api/server/data', json={'source_ip': '192.168.1.100', 'sample_id': 0}); print(r.status_code, r.json()['details'])"
```
- **Observed Output**: HTTP 200 OK (`FORWARDED`), `ids_classification: Benign`, `traffic_family: Benign`, `ground_truth_status: Dataset: 0`, `location: Private Network`.

### Step 3: Unmodified Attack Flow (Detected)
```powershell
.\.venv\Scripts\python.exe -c "import requests; r = requests.post('http://localhost:8000/api/server/data', json={'source_ip': '10.0.1.50', 'sample_id': 11}); print(r.status_code, r.json()['details'])"
```
- **Observed Output**: HTTP 403 Forbidden (`BLOCKED`), `ids_classification: Attack`, `traffic_family: Bot`, `ground_truth_status: Dataset: 1`, `location: Private Network`.
- Dashboard updates: Total Traffic increments to 2, Detected Attacks to 1, Recall computes as 1.000, FPR computes as 0.000.

### Step 4: Three Study-Defined Attack Methods
Launch the interactive attacker console:
```powershell
.\.venv\Scripts\python.exe attacker_sim.py
```
1. **Option 3: Silent Probing**:
   - Submits unchanged evaluation flows without querying target oracle (0 queries during synthesis).
   - Demonstrates baseline detection under passive probe.
2. **Option 4: Surrogate Transferability Attack**:
   - Queries target oracle over benign and attack reference samples to train local Decision Tree surrogate.
   - Evaluates black-box transferability of surrogate-crafted perturbations.
3. **Option 5: Decision Boundary Attack (1D Bisection Search)**:
   - Queries target oracle over network loopback within 50-query budget.
   - Demonstrates bisection search crossing decision boundary into benign prediction space.

### Step 5: Recall-Aware 5-Decision Controller Cadence
1. From `attacker_sim.py`, choose **Option 7** (Local Control-Path Demonstration: Base vs Recall-Aware).
2. The script transmits 5 identical attack flows under Base mode (static calibrated intensity $\varepsilon = 0.0003$), resets state, and transmits the same 5 flows under Recall-Aware mode.
3. **Points to Explain to Committee**:
   - The local demonstration evaluates feedback every 5 labeled attack decisions to illustrate the control path interactively.
   - When all 5 real demo attacks are detected (5/5 TP), rolling recall is 1.0, and the controller conditionally reports that it remains at its calibrated ceiling $\varepsilon = 0.00030$.
   - Point the committee to `tests/verify_defense_readiness.py` Check 7 (Part B) for the verified low-recall adaptation proof where a genuine `DecisionBoundaryAttack` evasion candidate crafted from attack sample 10 triggers fast-decay adaptation from $0.00030 \to 0.00012$, and flow 6 uses $0.00012$.

---

## 6. Explicit Presentation Limitations

To maintain academic rigor and adhere to thesis standards, the presenter must communicate these boundaries:

1. **Local Demonstration vs. Official Research Protocol**:
   - The standalone tool is a flow-feature HTTP demonstration. It demonstrates the live feedback control loop and inline defense mechanics.
   - It does **not** reproduce or substitute for the formal Phase 10/11 evaluation (which evaluated 144 measurement batches of 500 flows each against frozen test caches).
   - Thesis statistical performance tables cited during the presentation originate from the frozen research package, not the live dashboard counters.
2. **Feature-Flow Simulation vs. Live Packet Capture**:
   - The IDS evaluates 78-feature numerical vectors (CSE-CIC-IDS2018 schema).
   - The platform does not perform raw PCAP packet sniffing or online CICFlowMeter feature extraction.
3. **Simulation Feedback vs. Autonomous Label Discovery**:
   - Ground truth (`is_attack`) is post-decision simulation feedback provided by the simulator session to close the controller loop. Authoritative dataset labels always take precedence over simulator feedback for exact dataset samples. The IDS does not possess autonomous label discovery for arbitrary production traffic.
4. **Geolocation Attribution**:
   - Without an enterprise offline GeoIP database, public IPs are truthfully labeled as `Unknown` rather than populated with synthetic country coordinates.
5. **Offline Map Rendering**:
   - The dashboard application code, charts, and Leaflet controls run fully offline. Online basemap tiles require internet connectivity; when offline, Leaflet gracefully displays a neutral grid canvas.

---

## 7. Deliverable Archive & Manifest Verification

A clean, standalone audit ZIP has been prepared excluding git history, virtual environments, bytecode caches, inactive legacy files (`models/`, `datasets/demo/`), and historical prototype code (`archive/`).

- **Manifest Attestation**: The included `FILE_MANIFEST.csv` lists every file in the package along with its byte size and cryptographic SHA-256 hash.
- **External Archive Hash**: Per secure packaging standards, the final ZIP archive's SHA-256 checksum and exact byte size are published outside the archive in the audit handoff statement.

### Key Manifest Files & Verified Hashes
- `runtime_package/model/frozen_rf.joblib`: `9608672c5d5e38a9272c560679cdd2291399de0e0917c8c9dff373bfd200f51d` (55,251,670 B)
- `runtime_package/model/feature_mask.json`: `ee9bae9fbd552d5c92a43b9475ebaee79356f0d8b74de2d04c1c10689c158a55` (3,033 B)
- `runtime_package/model/feature_names.json`: `4ee6b2d9127a423eb3f7da3cb1ab6d644b3a90a4a0e378fe780528b2b009148c` (1,541 B)
- `runtime_package/model/training_bounds.parquet`: `9554f1b0287c88b5ef7b8de19d193184f2d76eec2b4d96f1fa525818cffb275b` (3,552 B)
- `runtime_package/demo_data/X_demo.parquet`: `a39f6ed3de09ae11dae5c271df515abb440a839567e2f8fa5394764e1e6dbada` (47,911 B)
- `runtime_package/demo_data/metadata_demo.parquet`: `593479e0275fc715d7534ee8d9a67805a47cd0c9ec9ed7d2d53b02beaff0a5db` (4,394 B)
- `server.py`: Verified in `FILE_MANIFEST.csv`
- `attacker_sim.py`: Verified in `FILE_MANIFEST.csv`
- `tests/verify_defense_readiness.py`: Verified in `FILE_MANIFEST.csv`

---
*Report certified defense-ready for presentation on October 8, 2026.*
