# TOOL_AUDIT_NOTES — Traceability & Code Evidence

This document traces the 10 core runtime questions to source paths, functions, and line numbers.
Evidence levels:
- **Verified in source**: Inspected and verified directly in codebase.
- **Observed in local test**: Executed live and confirmed by automated test assertion.
- **Inferred**: Derived logically from architectural design.
- **Unknown**: Not determinable from local code artifacts.

---

### Q1. What exact model file is loaded, and where do binary predictions originate?
- **Status**: [Verified in source, observed in local test]
- **Exact Model File**: `runtime_package/model/frozen_rf.joblib` (52,708,096 bytes).
- **Loading Location**: `server.py:144-145` (`SecurityEngine.load_resources`):
  ```python
  self.model = joblib.load(m_dir / "frozen_rf.joblib")
  ```
- **Model Details**: Serialized `sklearn.ensemble.RandomForestClassifier` with 200 decision trees trained on CSE-CIC-IDS2018, requiring exactly 78 numeric features. Output classes are strictly binary: `[0, 1]`.
- **Prediction Origin**:
  - For AFP / FS / None (`server.py:537-538`):
    ```python
    proba = engine.model.predict_proba(X_proj)[0]
    pred_label = int(np.argmax(proba))
    ```
  - For Randomized Smoothing (`server.py:541-553`):
    ```python
    preds, _, vote_frac = engine.defenses["rs"].predict_ensemble(
        features.reshape(1, -1),
        sigma=curr_intensity,
        seed=int(time.time() * 1000) % (2**31 - 1),
        attack_scenario=req.attack_scenario or "live",
        batch_id=engine.batch_id,
        predict_func=engine.model.predict,
        return_scores=True
    )
    pred_label = int(preds[0])
    ```
  - Binary String Mapping (`server.py:560`):
    ```python
    pred_str = "Attack" if pred_label == 1 else "Benign"
    ```
- **Authoritative Nature**: The model strictly outputs 0 or 1. No multiclass labels (`DDoS`, `Bot`, `Silent Probing`, etc.) are ever produced by the model.

---

### Q2. What preprocessing and feature order does runtime inference use?
- **Status**: [Verified in source]
- **Feature Schema & Order**: Exactly 78 numerical flow features in alphabetical order matching CSE-CIC-IDS2018, loaded from `runtime_package/model/feature_names.json` (`server.py:147-148`).
- **Modifiable Mask**: 42 modifiable features and 36 immutable features, loaded from `runtime_package/model/feature_mask.json` (`server.py:150-152`).
- **Feature Clipping**: Loaded from `runtime_package/model/training_bounds.parquet` (`server.py:154`). Input vectors are clipped to `[min, max]` bounds at `server.py:527-530`:
  ```python
  for i, col in enumerate(engine.feature_names):
      if col in engine.bounds_df.index:
          low = engine.bounds_df.loc[col, "min"]
          high = engine.bounds_df.loc[col, "max"]
          features[i] = np.clip(features[i], low, high)
  ```
- **Scaler Note**: `runtime_package/model/standard_scaler.joblib` exists in the repository from earlier pipeline phases, but Random Forest decision trees operate directly on unscaled, clipped features (`X_proj`).

---

### Q3. What request/data path does each attack scenario take to reach inference?
- **Status**: [Verified in source, observed in local test]
- **Attacker Console (`attacker_sim.py`)**:
  - **Silent Probing** (`attacker_sim.py:321-360`): Explores feature space with 0 queries to target oracle during generation (`SilentProbingAttack.generate(x_val, oracle=None)`). Candidate $X_{	ext{adv}}$ transmitted via HTTP POST to `/api/server/data`.
  - **Surrogate Transferability** (`attacker_sim.py:363-415`): Fits a local Decision Tree surrogate using labels queried from target oracle (`RemoteServerOracle.predict()`), extracts benign interval paths, evaluates transferability, and transmits final $X_{	ext{adv}}$ via HTTP POST.
  - **Decision-Boundary Attack** (`attacker_sim.py:418-475`): Queries target oracle via `RemoteServerOracle.predict()` over HTTP (budget $\le 50$ queries). Conducts 1D bisection search between attack flow and benign reference pool (`ref_pool`) to cross decision boundary, transmitting final $X_{	ext{adv}}$ via HTTP POST.
- **Server Reception & Evaluation (`server.py:492-570`)**:
  - `server.py:499-501`: Evaluates caller's actual 78-feature vector (`req.feature_vector`) with strict priority.
  - `server.py:527-530`: Enforces bounds clipping.
  - `server.py:532-558`: Applies active defense transformation (`AFP`, `RS`, `FS`, or `None`).
  - `server.py:537, 542`: Evaluates through `engine.model`.
  - `server.py:564-572`: Returns `HTTP 403 Forbidden` if Attack, `HTTP 200 OK` if Benign.

---

### Q4. Can scenario selection or ground truth influence the displayed IDS classification?
- **Status**: [Verified in source, observed in local test]
- **Independence Verified**:
  - `engine.model.predict_proba` or `predict_ensemble` receives only the feature vector `X_proj`.
  - `req.attack_scenario` is recorded strictly as session metadata for display in the recent feed, attacks table, and forensics inspector (`server.py:562, 584`). It is NEVER passed to the Random Forest model.
  - `req.is_attack` is recorded as ground truth and passed to `engine.update_metrics_and_controller(ground_truth, pred_label)`. It NEVER overrides `pred_label`.
  - Selecting an attack scenario does NOT force an Attack prediction. In Test C, an attack sample perturbed by Decision-Boundary Attack crosses into the benign region, resulting in `ids_classification: Benign`, `verdict: FORWARDED`, and `HTTP 200 OK`, while `attack_scenario` remains `Decision-Boundary Attack`.

---

### Q5. How do RS, FS, AFP, Base, and Recall-Aware modes enter the processing path?
- **Status**: [Verified in source]
- **Defense Transformation (`server.py:531-558`)**:
  - **AFP**: `engine.defenses["afp"].defend(features, epsilon_base=curr_intensity, alpha=engine.afp_alpha, ...)` projects modifiable features toward benign profile centroids (`afp_benign_profile.parquet`).
  - **RS**: `engine.defenses["rs"].predict_ensemble(features, sigma=curr_intensity, ...)` draws 11 Gaussian noise samples and takes ensemble majority vote.
  - **FS**: `engine.defenses["fs"].defend(features, intensity=curr_intensity, ...)` quantizes continuous features into bins.
  - **None**: Features pass directly to model without perturbation.
- **Controller Modes**:
  - **Base Mode**: `curr_intensity` is fixed to static base intensity (`0.0003` for AFP, `0.05` for RS, `10.0` for FS).
  - **Recall-Aware Mode**: `curr_intensity` is dynamically modulated by `RecallAwareController` based on rolling recall feedback.

---

### Q6. Does runtime Recall-Aware behavior operate per flow or per batch, and where does feedback come from?
- **Status**: [Verified in source, observed in local test]
- **Feedback Origin**: Simulation harness provides post-decision ground truth via `req.is_attack`.
- **Per Flow vs Per Batch**:
  - Individual flow decisions increment running confusion matrix counters (`tp`, `fp`, `fn`, `tn`, `batch_tp`, `batch_fn`).
  - Controller intensity updates operate **per batch of 5 attack decisions** (`server.py:273-282`):
    ```python
    if (self.batch_tp + self.batch_fn) >= self.batch_size: # batch_size = 5
        update = self.controller.submit_observations(self.batch_id, self.batch_tp, self.batch_fn)
        self.controller_state = update.state
        self.current_intensity = update.clipped_next_intensity
        self.batch_id += 1
        self.batch_tp = 0
        self.batch_fn = 0
        self.controller.get_intensity(self.batch_id)
    ```
- **Causal Separation Rule**: Batch $t$ decisions use the intensity chosen before batch $t$ labels were seen. Batch $t$ observations update intensity for batch $t+1$.

---

### Q7. Where do traffic family, IP address, and geolocation values originate?
- **Status**: [Verified in source, observed in local test]
- **Traffic Family (`server.py:513-525`)**:
  - If `sample_id` is a valid index into `runtime_package/demo_data/metadata_demo.parquet`: resolved from `metadata_demo.iloc[sample_id]["attack_family"]` and marked `"Dataset-derived"`.
  - Otherwise, strictly assigned `"Unknown"` with source `"Synthetic / Non-dataset"`. Client-supplied strings cannot override this.
- **IP Address**: Supplied in request payload `req.source_ip`. Generated in `attacker_sim.py` from `ORIGIN_POOL` (attacks) or `BENIGN_POOL` (benign).
- **Geolocation (`server.py:425-447`)**:
  - RFC 1918 subnets (`10.x`, `172.16-31.x`, `192.168.x`, `127.x`) resolve strictly to `"Private Network"`.
  - Public IPs resolve strictly to `"Unknown"` because no offline MaxMind `.mmdb` database is bundled. No country fabrication occurs.

---

### Q8. Where does every key dashboard metric/feed value originate?
- **Status**: [Verified in source, observed in local test]
- **Server Telemetry (`server.py:328-369`)**:
  - `stats.total_traffic`: Integer counter initialized to 12,482, increments +1 per flow.
  - `stats.detected_attacks`: Integer counter, increments when `pred_label == 1`.
  - `stats.detection_recall`: Computed as `tp / (tp + fn)`.
  - `stats.false_positive_rate`: Computed as `fp / (tn + fp)`.
  - `afp.intensity`: `self.current_intensity` from controller.
  - `afp.controller_state`: `self.controller_state` (`Green`, `Yellow`, `Red`, `Base`, `Bypassed`).
  - `recent_feed`: 50-entry rolling ring buffer broadcast over WebSocket to frontend.
  - `history`: Deque of timestamps, recall values, and intensity values rendered on Chart.js.
  - `threat_locations`: 8 pre-seeded global pins for Leaflet map display.
- **Frontend Unpacker (`frontend/app.js:310-380`)**:
  - WebSocket handler updates KPI cards, timeline chart, threat map pins, feed table, and forensics inspector cards.

---

### Q9. What is generated, hard-coded, mock, random, replayed, or dataset-derived?
- **Status**: [Verified in source]
- **Dataset-derived**:
  - `X_demo.parquet` (20 flows from CSE-CIC-IDS2018).
  - `metadata_demo.parquet` (labels and attack families).
  - `frozen_rf.joblib` (Random Forest model trained on dataset).
  - `feature_names.json`, `training_bounds.parquet`, `afp_benign_profile.parquet`.
- **Real Computed Runtime**:
  - Feature clipping, AFP projection, RS ensemble noise draws, FS quantization.
  - Random Forest predictions (`predict_proba`, `predict`).
  - Recall-Aware rolling recall, state transitions (Green/Yellow/Red), and intensity adjustments.
  - HTTP status codes (200 OK vs 403 Forbidden).
- **Pre-seeded Baseline Warmup**:
  - Baseline counters in `server.py:89-96` (`total_traffic=12482`, `tp=84`, etc.) and initial 11 timeline chart history points.
- **Mock / Predefined**:
  - `threat_locations` in `server.py:104-113` (8 static coordinates for map pins).
  - `ORIGIN_POOL` and `BENIGN_POOL` in `attacker_sim.py:77-97` (pool of source IPs).

---

### Q10. What is known to be incomplete, untested, or potentially inconsistent?
- **Status**: [Verified in source]
- **Flow-Feature Scope**: The IDS operates on 78 numerical features. It does not inspect raw PCAP packets or execute live CICFlowMeter feature extraction.
- **Offline GeoIP Database**: Public IPs resolve to `Unknown` because no external `.mmdb` database is included.
- **Simulation Feedback**: Ground truth is provided post-decision by the simulation harness (`is_attack`); unlabelled online traffic would require external verification.
- **Legacy Artifacts**: The root directory contains legacy 77-feature files in `models/` (`rf_ids_cic.pkl.xz`, `X_bounds_cic.json`, `X_ref_cic.json`) from an early prototype. These are completely bypassed by the runtime, which exclusively uses the 78-feature files in `runtime_package/model/`.
