# PACKAGE_README — Standalone IDS + Recall-Aware Research Platform

## 1. Snapshot Metadata
- **Repository Root**: `c:/Users/reddr/ai_recreation`
- **Current Branch**: `integrate-runtime-demo`
- **Commit SHA**: `df32f5e7fe2d3975b00d53017f135571a90c5ad1`
- **Working-Tree Status**:
  - Unstaged modifications included in package:
    - `requirements.txt`: Standardized dependencies for FastAPI, Uvicorn, Scikit-learn, Parquet.
    - `runtime_package/run.py`: Fixed C1 config lookup (`c_cfg["controller_configurations"]["C1"]`) and 5-attack batching cadence.
    - `server.py`: Fixed feature-vector precedence bug, strict provenance enforcement, RS vote-fraction confidence.
    - `tests/test_master_directive.py`: Implemented genuine adversarial evasion test using attack sample 10.
  - Untracked files included in package:
    - `AUDIT_NOTES.md`: Authoritative runtime audit notes.
    - `tests/run_audit_tests.py`: Automated 7-test runtime audit suite (Tests A-G).
- **Package Creation Time**: 2026-10-06T11:55:00+08:00
- **Package Nature**: Standalone IDS demonstration platform with inline defenses, Recall-Aware controller, local black-box attacker simulator, and real-time SOC dashboard.

---

## 2. Installation & Running Instructions

### Prerequisites
- Python 3.10 - 3.13
- Node.js / npm NOT required (frontend is vanilla HTML/JS/CSS served directly by FastAPI)

### Setup
```powershell
# Create and activate virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1   # On Linux/macOS: source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Starting the Protected Server & SOC Dashboard
```powershell
# Terminal 1: Run the backend server
python server.py
```
- Open browser at `http://localhost:8000`.
- The SOC dashboard renders real-time KPI metrics, dual-axis timeline, Leaflet threat map, live detection feed, and forensic inspection cards.

### Running the Attacker Simulation Console
```powershell
# Terminal 2: Run the attacker simulation console
python attacker_sim.py                      # Interactive menu console
python attacker_sim.py --mode silent        # Silent Probing Attack
python attacker_sim.py --mode surrogate     # Surrogate Transferability Attack
python attacker_sim.py --mode boundary      # Decision-Boundary Bisection Attack
python attacker_sim.py --mode stream        # Continuous real-time stream
python attacker_sim.py --mode compare       # Base Defense vs Recall-Aware Benchmark
```

### Running the Automated Test Suites
```powershell
# Run the 5-test master directive pytest suite
pytest tests/test_master_directive.py -v

# Run the 7-test comprehensive runtime audit runner (Tests A - G)
python tests/run_audit_tests.py
```

---

## 3. Environment Variables
- **Required**: NONE. The application is completely self-contained and pre-configured for local execution.
- **Optional**:
  - `PORT`: Server port (default: `8000`).
  - `HOST`: Server bind address (default: `0.0.0.0` or `127.0.0.1`).
- *No passwords, API keys, secrets, or tokens are required or used.*

---

## 4. Entry Points & Architecture Map

```text
attacker_sim.py (Attacker Client Console)
       │ HTTP POST /api/server/data (78-feature vector + sample_id)
       ▼
server.py (FastAPI Protected Server)
       ├── feature clipping (training_bounds.parquet)
       ├── runtime_package/defenses/ (AFP / RS / FS / None)
       ├── runtime_package/controller/ (Recall-Aware C1 feedback loop)
       └── runtime_package/model/frozen_rf.joblib (Authoritative Binary Random Forest)
       │
       ├── WebSockets (/ws) & REST (/api/dashboard/*)
       ▼
frontend/ (SOC Dashboard: index.html, app.js, style.css)
```

- **`server.py`**: Protected backend server exposing HTTP ingestion, inline defenses, model inference, and WebSocket telemetry.
- **`attacker_sim.py`**: Black-box attacker simulation console implementing Silent Probing, Surrogate Transfer, and Decision-Boundary bisection attacks.
- **`runtime_package/run.py`**: Standalone offline simulation CLI comparing undefended, base-defended, and recall-aware defended runs.
- **`frontend/`**: SOC dashboard UI (Chart.js, Leaflet.js, and forensics inspector).

---

## 5. Runnable Assessment
- **Standalone Runnable**: **YES**. All runtime models (`frozen_rf.joblib`), schemas (`feature_names.json`, `feature_mask.json`), calibration bounds (`training_bounds.parquet`), benign centroids (`afp_benign_profile.parquet`), and demo samples (`X_demo.parquet`, `metadata_demo.parquet`) are fully included in this archive.
- Missing dependencies: None, beyond standard Python packages listed in `requirements.txt`.
