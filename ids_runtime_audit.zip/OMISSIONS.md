# OMISSIONS — Excluded Artifacts & Scope Boundary Notes

The following files and directories were intentionally excluded from `ids_standalone_tool_audit.zip`. This document details their location, size, rationale, and impact on tool execution.

---

## 1. Excluded Files & Directories

| Item | Location | Size | Reason for Omission | Runnable Impact |
| :--- | :--- | :--- | :--- | :--- |
| `.git/` | Repository Root | ~100+ MB | Version control repository internals, commit history, and packfiles. | **None**. Application does not depend on git at runtime. |
| `.venv/` | Repository Root | ~1.5 GB | Virtual environment binaries, compiled wheels, and site-packages. | **None**. Dependencies are fully captured in `requirements.txt`. |
| `__pycache__/`, `.pytest_cache/` | Workspace-wide | ~5 MB | Compiled Python bytecode (`.pyc`) and pytest cache artifacts. | **None**. Recompiled automatically on startup. |
| `models/rf_ids_cic.pkl.xz` | `models/` | 58.1 MB | Legacy 77-feature prototype model from early repository scaffolding. Superseded by authoritative 78-feature `runtime_package/model/frozen_rf.joblib`. | **None**. Server and runtime package strictly load `frozen_rf.joblib`. |
| `models/X_bounds_cic.json` | `models/` | 7.7 KB | Legacy 77-feature bounds file from early scaffolding. | **None**. Runtime uses `runtime_package/model/training_bounds.parquet`. |
| `models/X_ref_cic.json` | `models/` | 7.9 KB | Legacy 77-feature reference profile from early scaffolding. | **None**. Runtime uses `runtime_package/model/afp_benign_profile.parquet`. |
| `archive/` | Repository Root | ~12 MB | Historical repository artifacts: presentation slides, extra datasets, legacy Streamlit apps, and Jupyter notebooks. | **None**. The active tool uses `server.py` and `frontend/`. |
| `datasets/demo/X_test_demo.csv` | `datasets/demo/` | 4.3 MB | Legacy CSV demo dataset. Superseded by `runtime_package/demo_data/X_demo.parquet`. | **None**. Runtime strictly loads Parquet demo data. |
| `datasets/demo/y_test_demo.csv` | `datasets/demo/` | 15 KB | Legacy CSV demo metadata. Superseded by `runtime_package/demo_data/metadata_demo.parquet`. | **None**. Runtime strictly loads Parquet demo metadata. |
| `ids_runtime_audit.zip` | Repository Root | 14.3 MB | Pre-existing zip archive in root. Excluded to prevent redundant recursive zip nesting. | **None**. Target archive `ids_standalone_tool_audit.zip` contains all active files. |

---

## 2. Redacted Secrets Check

- **Scan Results**: The repository was scanned for `.env` secrets, database connection URIs, private keys, authentication tokens, and passwords.
- **Embedded Secrets Found**: **NONE**. The application operates entirely locally with no external cloud, database, or API credentials.
- **Redacted Files**: **NONE**.

---

## 3. Completeness Declaration

All artifacts required to run the backend server, serve the frontend SOC dashboard, execute the black-box attacker simulator, perform model inference, apply defenses, and run automated tests are **100% included** in `ids_standalone_tool_audit.zip`.
